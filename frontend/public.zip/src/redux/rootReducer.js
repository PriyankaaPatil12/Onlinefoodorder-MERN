import { combineReducers } from "redux";
import pizzaReducer from "./pizza/Reducer";
import cartReducer from "./cart/Reducer";


const rootReducer = combineReducers({
    pizza:pizzaReducer,
    cart:cartReducer
  });
  
  export default rootReducer;